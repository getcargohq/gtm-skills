# Configure CRM deduplication

Use this reference after the operator approves the audit, matching keys, protected fields, survivor
precedence, automatic-merge class, and manual-review destination.

## Build on the CRM model

Run `deduplicate_accounts` directly on the CRM-backed `crm_accounts` model. The folder is isolated,
so it declares a checked HubSpot connector and model. When the consumer project already has
compatible resources, rewire the play to them and remove the copies. The plan must contain one CRM
account model, not a candidate or staging model.

The play's filter requires the audited CRM record ID and at least one supported identifier. Keep
`isEnabled: false`, `runCreationRule: noConcurrency`, `limit: 15`, and a daily schedule.

For the checked HubSpot shape, verify the live integration before adaptation:

```sh
cargo-ai connection integration get hubspot
```

The checked graph uses these actions:

| Node                     | HubSpot action | Purpose                                                 | Required payload                                            |
| ------------------------ | -------------- | ------------------------------------------------------- | ----------------------------------------------------------- |
| Find duplicate companies | `findRecords`  | Search live companies using non-empty identity criteria | `objectType`, `criterias[]` with `propertyName` and `value` |
| Merge exact cluster      | `mergeRecords` | Merge automatically approved child records              | `objectType`, `primaryId`, `idsToMerge`                     |
| Merge reviewed cluster   | `mergeRecords` | Merge only after Human Review approval                  | `objectType`, `primaryId`, `idsToMerge`                     |

`findRecords` skips empty criterion values. Pass LinkedIn company ID, LinkedIn company page, and
domain. Retain the source CRM row exactly once in the cluster, normalize all candidate values, and
reject a generic-domain-only match. The search is the fresh CRM reread for that run.

Add one Slack connector, bound to the workspace default, for Cargo's native Human Review node.
Replace `PLACEHOLDER_REVIEW_CHANNEL_ID` with the approved channel before planning. If no review
connector and channel can be resolved, keep the play disabled and stop before a pilot.

Set no connector cache. Every merge decision rests on what the CRM returns during the run, and a
cached read is the one kind of staleness the fresh-source guard cannot see.

## Score and select the survivor

The compiled graph contains one native Scoring node after evidence preparation:

| Evidence                                                | Score |
| ------------------------------------------------------- | ----: |
| Exact LinkedIn company ID across the cluster            |    60 |
| Exact LinkedIn company URL or handle across the cluster |    25 |
| Exact non-generic domain across the cluster             |    15 |

The score explains confidence. It does not replace the conflict gate. A score of at least 60 can
merge automatically only when every record has the same non-empty LinkedIn company ID and every
conflict flag is false. LinkedIn URL plus domain remains manual even when both agree.

The default survivor precedence, in the survivor-selection script, is:

1. record with a protected business ID
2. customer record
3. most open opportunities
4. most contacts
5. most activities
6. most populated properties
7. latest activity
8. oldest creation time
9. lexicographically smallest CRM record ID

Map the approved protected-ID and parent-company properties into the checked workflow inputs.
When the operator changes precedence, change the sort in the survivor script and the expected
survivor in `evals/contract.mjs` together.

## Guard merge and review

The automatic branch requires all of these:

- at least one other CRM record remains after the fresh search
- duplicate score is at least 60
- every record has the same non-empty normalized LinkedIn company ID
- no non-null LinkedIn ID, LinkedIn URL, or domain conflicts
- no protected business ID conflict
- no parent-subsidiary relationship inside the cluster

The yes path calls `mergeRecords` with the deterministic survivor as `primaryId` and every other CRM
record ID as `idsToMerge`. The no path enters native Human Review. Its message shows the score,
survivor, child IDs, conflict flags, and normalized candidate evidence. Approval calls the same
merge action. Decline or timeout ends with `review_declined_or_timed_out` and makes no CRM write.

If the source row is missing from the fresh search because an earlier queued merge absorbed it, end
as `source_missing_or_changed` before scoring or emitting merge IDs.

## Configure contact deduplication

Run `deduplicate_contacts` directly on `crm_contacts`. Its first live search uses LinkedIn person ID,
four normalized LinkedIn URL variants, email, and phone. A second live search expands every key from
the direct results so pairwise high-confidence matches can form one transitive cluster.

The contact score assigns 60 to exact LinkedIn person ID, exact LinkedIn URL without person-ID
conflict, exact non-generic email without LinkedIn conflict, and a transitive chain of those classes.
The automatic gate requires the score plus `autoEligible`. That guard disqualifies every class when
the cluster has a LinkedIn identity conflict or generic/shared email. Phone-only groups go to Human
Review when enabled and otherwise remain untouched.

After an automatic or approved merge, write validated non-empty `email`, `phone`, `linkedin_url`,
`linkedin_person_id`, and `jobtitle` values to the `id` returned by `mergeRecords`. Do not target the
pre-merge primary ID because HubSpot may create a new record ID. Do not include
`associatedcompanyid` in `updateRecords`; it is read-only. If policy requires changing a company
association, add and validate a supported HubSpot Associations API action during adaptation.

Both models belong to the `crm-deduplication-models` folder and both plays belong to the
`crm-deduplication-plays` folder. Keep both connectors uncached, both plays disabled and serial, and
each pilot limited to 15 rows.

## Complete when

- the CDK plan contains only the CRM and review connectors, two ownership folders, both CRM models,
  and both dedup plays
- `deduplicate_accounts` runs directly on `crm_accounts` and `deduplicate_contacts` on `crm_contacts`
- the graph is CRM search, preparation (evidence and survivor in one script), native Scoring,
  guarded Branch, then CRM merge or native Human Review
- automatic merge requires exact shared LinkedIn company ID and every conflict guard
- Human Review approval reaches the reviewed merge; decline and timeout reach the no-write end
- contact write-back uses the merge response ID and excludes `associatedcompanyid`
- both plays are disabled, use `noConcurrency`, and limit each pilot to 15 CRM rows
- `node --import tsx evals/contract.mjs` passes after every adaptation
